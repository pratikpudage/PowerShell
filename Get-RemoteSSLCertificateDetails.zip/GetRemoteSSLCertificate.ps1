﻿<#
.SYNOPSIS
This script helps in extracting SSL certificate details for each computer against which the script is run.


.DESCRIPTION
This script will:

 - Perform Test-NetConnection on port 443
 - Calls another script Get-RemmoteSSLCerts.ps1 to check SSL certificate against the server and export it's details to a CSV file.


.NOTES
Author: Pratik Pudage (PratikPudage@hotmail.com)
Version 2.0


#>

$Results = @()
$Computers = Get-Content .\Input.txt
$Output = '.\CertificateDetails.csv'

foreach($Computer in $Computers)
{
$TCPTest = Test-NetConnection -ComputerName $Computer -Port 443
$CertResult = .\Get-RemoteSSLCerts.ps1 -ComputerName $Computer


      $Properties = @{
      IPAddress = $TCPTest.RemoteAddress
      TCPTestSuccess = $TCPTest.TcpTestSucceeded
      ComputerName = $Computer
      CertificateSubject = $CertResult.Subject
      ThumbPrint = $CertResult.Thumbprint
      Issuer = $CertResult.Issuer
      Expires = $CertResult.NotAfter
      }
      

$Results += New-Object psobject -Property $properties

}

$Results | Select-Object ComputerName,IPAddress,TCPTestSuccess,CertificateSubject,ThumbPrint,Issuer,Expires |Export-Csv $Output -NoTypeInformation